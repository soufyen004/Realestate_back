# laravel-passport-auth

[Laravel 7|8 REST API with Passport Authentication ]

# for RealEstate react js app

# Default Credentials : admin@admin.com / password